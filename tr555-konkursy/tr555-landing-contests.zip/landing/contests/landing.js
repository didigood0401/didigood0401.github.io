(function(){
  var reduce = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var nf = function(n){ return String(n).replace(/\B(?=(\d{3})+(?!\d))/g, ' '); };
  function plural(n, a, b, c){ n = Math.abs(n) % 100; var d = n % 10; return n > 10 && n < 20 ? c : d === 1 ? a : d > 1 && d < 5 ? b : c; }

  /* Яндекс Метрика: номер счётчика (0 = выключено, на tr555.ru счётчик уже подключён через /metrika.js) */
  var YM_ID = 111803113;
  function goal(name){ if (YM_ID && window.ym) ym(YM_ID, 'reachGoal', name); }

  /* метки рекламы (utm_*, yclid) передаём дальше на tr555.ru, цели — по кликам */
  var tags = (location.search.slice(1).split('&')).filter(function(p){ return /^(utm_\w+|yclid)=/.test(p); }).join('&');
  document.addEventListener('click', function(e){
    var a = e.target.closest && e.target.closest('a[href^="https://tr555.ru"]');
    if (!a) return;
    var h = a.getAttribute('href');
    goal(/\/register/.test(h) ? 'register_click' : /\/login/.test(h) ? 'login_click'
       : /\/contests/.test(h) ? 'contest_click' : 'site_click');
    if (tags && !a.dataset.tagged){ a.href = h + (h.indexOf('?') < 0 ? '?' : '&') + tags; a.dataset.tagged = 1; }
  });

  /* заголовок под объявление Директа: ?v=money | prose | scenario | start */
  var V = {
    money:    ['Ваш рассказ может <span class="gold">принести деньги</span>', 'Пишите в тему с призом и собирайте лайки и рецензии читателей. Кто первым наберёт порог баллов, получает приз на свой счёт.'],
    prose:    ['Конкурс для тех, кто пишет <span class="hl">прозу</span>', 'Рассказы о городе, будущем и людях в нём. Каждый текст и каждая рецензия приближают вас к призу.'],
    scenario: ['Напишите сценарий и <span class="gold">выиграйте приз</span>', 'Продолжение фильма, сценарий игры, история про телепорт. В конкурсных темах ваша идея может стоить денег.'],
    start:    ['Первый текст и <span class="hl">сразу в конкурс</span>', 'Все стартуют с нуля: старые тексты не считаются, поэтому у новичка столько же шансов, сколько у опытного автора.']
  };
  var v = (location.search.match(/[?&]v=(\w+)/) || [])[1];
  if (V[v]){ document.querySelector('.hero h1').innerHTML = V[v][0]; document.querySelector('.hero .lead').textContent = V[v][1]; }

  /* живая карточка конкурса: баллы капают, на 100 — уведомление */
  var P = {m:5, l:10, r:20}, TH = 100;
  var people = [['ИВ','Ира Вельт'],['ДК','Дима Корн'],['АС','Аля Сим'],['ТР','Тим Рокс'],['МН','Маша Нор'],['ГЛ','Гоша Лис'],['ЕБ','Ева Бран']];
  /* темы по кругу: после каждого приза карточка переключается на следующую */
  var T = [
    {n:'Телепорт', s:'Сценарии', p:5000, t:100, d:5*24+6, mats:['Обратный билет','Двойник на перроне','Последняя кабина','Шум в канале']},
    {n:'Город через 50 лет', s:'Проза', p:3000, t:60, d:8*24+23, mats:['Крыши без проводов','Лифт на сороковой','Утро без пробок']},
    {n:'Боевой ИИ: как его переиграть', s:'Технологии', p:4000, t:80, d:13*24, mats:['Слепая зона','Ложный сигнал','Протокол тишины']},
    {n:'Первая зима на Марсе', s:'Проза', p:6000, t:120, d:3*24+17, mats:['Купол номер три','Письмо с Земли','Красная пыль','Теплица']},
    {n:'Машина времени на один день', s:'Сценарии', p:3500, t:80, d:10*24+4, mats:['Вчерашний звонок','Петля в 9:15','Чужой выпускной']}
  ];
  var pool = ['m','l','l','m','r','l','m','l','r','l','l','r','m','l'];
  var ti = 0, tp, mats, script, end, timer;
  var st, step, feed = document.getElementById('feed'), toast = document.getElementById('toast');
  function $(id){ return document.getElementById(id); }
  function paint(){
    var s = st.m*P.m + st.l*P.l + st.r*P.r, k = 100/Math.max(TH, s);
    $('sc').textContent = Math.min(s, 999);
    $('nm').textContent = st.m; $('nl').textContent = st.l; $('nr').textContent = st.r;
    $('pm').textContent = st.m*P.m + ' ' + plural(st.m*P.m,'балл','балла','баллов');
    $('pl').textContent = st.l*P.l + ' баллов'; $('pr').textContent = st.r*P.r + ' баллов';
    $('bm').style.width = st.m*P.m*k + '%'; $('bl').style.width = st.l*P.l*k + '%'; $('br').style.width = st.r*P.r*k + '%';
    return s;
  }
  function add(kind){
    st[kind]++;
    var li = document.createElement('li'), who = people[(step*3) % people.length], mt = mats[st.m ? (st.m-1) % mats.length : 0];
    var title = kind === 'm' ? 'Материал прошёл модерацию' : kind === 'l' ? 'Лайк от ' + who[1] : 'Рецензия от ' + who[1];
    li.innerHTML = '<span class="av ' + (kind === 'm' ? '' : kind) + '">' + (kind === 'm' ? '✎' : who[0]) + '</span>'
      + '<span class="tx">' + title + '<small>«' + mt + '» · только что</small></span><span class="pl num">+' + P[kind] + '</span>';
    feed.insertBefore(li, feed.firstChild);
    while (feed.children.length > 6) feed.removeChild(feed.lastChild);
    return paint();
  }
  function topic(i){
    ti = (i + T.length) % T.length; tp = T[ti]; TH = tp.t; mats = tp.mats;
    script = []; for (var s = 0, j = 0; s < TH; j++){ var k = pool[j % pool.length]; script.push(k); s += P[k]; }
    end = Date.now() + (tp.d*60 + 14)*60000; tick();
    $('ctopic').textContent = 'Конкурс в теме «' + tp.n + '»'; $('csec').textContent = tp.s;
    $('cprize').textContent = nf(tp.p) + ' ₽'; $('cth').textContent = $('cth2').textContent = TH;
    $('tt').textContent = 'Порог ' + TH + ' взят первым!';
    $('ts').textContent = 'Модератор проверит результат, и ' + nf(tp.p) + ' ₽ придут на ваш счёт.';
    dots.forEach(function(b, k){ b.setAttribute('aria-pressed', k === ti); });
  }
  var dots = T.map(function(t, k){
    var b = document.createElement('button'); b.type = 'button'; b.setAttribute('aria-label', 'Тема «' + t.n + '»');
    b.addEventListener('click', function(){ if (k !== ti) next(k); });
    $('tdots').appendChild(b); return b;
  });
  function next(i){
    clearTimeout(timer); toast.classList.remove('on'); $('cc').classList.add('swap');
    timer = setTimeout(function(){
      topic(i); reset(); $('cc').classList.remove('swap');
      if (reduce) full(); else timer = setTimeout(run, 700);
    }, 350);
  }
  function full(){ script.forEach(function(k){ add(k); step++; }); toast.classList.add('on'); }
  function reset(){
    st = {m:0, l:0, r:0}; step = 0; feed.innerHTML = ''; toast.classList.remove('on'); paint();
  }
  function run(){
    if (step >= script.length){ return; }
    var s = add(script[step++]);
    if (s >= TH){ timer = setTimeout(function(){ toast.classList.add('on'); timer = setTimeout(function(){ next(ti + 1); }, 5000); }, 500); return; }
    timer = setTimeout(run, 1000 + Math.random()*600);
  }
  topic(0); reset();
  if (reduce) full();
  else timer = setTimeout(run, 700);

  /* таймер */
  function tick(){ var ms = end - Date.now(), m = Math.floor(ms/60000), d = Math.floor(m/1440), h = Math.floor(m%1440/60), mm = m%60;
    $('timer').textContent = d + ' дн. ' + h + ' ч ' + (mm < 10 ? '0' : '') + mm + ' мин'; }
  tick(); setInterval(tick, 20000);

  /* калькулятор */
  var C = {m:2, l:3, r:1, t:100}, calcUsed = false;
  function ways(left){
    /* короткие сочетания, которыми можно добрать оставшиеся баллы */
    var out = [], maxM = 10 - C.m;
    for (var r = 0; r <= 5; r++) for (var l = 0; l <= 10; l++){
      var rest = left - r*20 - l*10, m = rest > 0 ? Math.ceil(rest/5) : 0;
      if (m > maxM) continue;
      if (r*20 + l*10 + m*5 - left >= 10 && (m || l || r)) continue;
      out.push({m:m, l:l, r:r, n:m+l+r});
    }
    out.sort(function(a, b){ return a.n - b.n || b.r - a.r; });
    var seen = {}, res = [];
    out.forEach(function(w){ var key = (w.r>0)+'' + (w.l>0) + (w.m>0); if (!seen[key] && res.length < 3){ seen[key] = 1; res.push(w); } });
    return res.map(function(w){
      var p = [];
      if (w.r) p.push(w.r + ' ' + plural(w.r,'рецензия','рецензии','рецензий'));
      if (w.l) p.push(w.l + ' ' + plural(w.l,'лайк','лайка','лайков'));
      if (w.m) p.push(w.m + ' ' + plural(w.m,'текст','текста','текстов'));
      return p.join(' + ');
    });
  }
  function calc(){
    var pm = Math.min(C.m, 10)*5, pl = C.l*10, pr = C.r*20, s = pm + pl + pr, k = 100/Math.max(C.t, s);
    $('cs').textContent = s; $('ct').textContent = C.t;
    $('cbm').style.width = pm*k + '%'; $('cbl').style.width = pl*k + '%'; $('cbr').style.width = pr*k + '%';
    var v = $('cv'), left = C.t - s;
    if (left <= 0){
      v.className = 'verdict ok'; v.textContent = 'Порог взят! Если вы первый, приз ваш после проверки модератора.';
      $('cwl').hidden = true; $('cw').innerHTML = '';
    } else {
      v.className = 'verdict'; v.textContent = 'До порога ' + left + ' ' + plural(left,'балл','балла','баллов') + '.';
      $('cwl').hidden = false;
      $('cw').innerHTML = ways(left).map(function(t){ return '<li>' + t + '</li>'; }).join('');
    }
    document.querySelectorAll('.stp').forEach(function(el){ el.querySelector('output').textContent = C[el.dataset.k]; });
  }
  document.querySelectorAll('.stp').forEach(function(el){
    var b = el.querySelectorAll('button'), k = el.dataset.k, max = k === 'm' ? 10 : 30;
    b[0].addEventListener('click', function(){ C[k] = Math.max(0, C[k]-1); used(); calc(); });
    b[1].addEventListener('click', function(){ C[k] = Math.min(max, C[k]+1); used(); calc(); });
  });
  document.querySelectorAll('#thr button').forEach(function(b){
    b.addEventListener('click', function(){
      C.t = +b.dataset.t; used();
      document.querySelectorAll('#thr button').forEach(function(x){ x.setAttribute('aria-pressed', x === b); });
      calc();
    });
  });
  function used(){ if (!calcUsed){ calcUsed = true; goal('calc_use'); } }
  calc();


  /* v2: одно окно, темы конкурсов сменяют друг друга сами */
  var R = [
    {s:'Сценарии', n:'Телепорт', h:'Кабина ошиблась адресом. Куда попал герой и как ему вернуться?', p:5000, d:'5 дн. 6 ч', t:100},
    {s:'Проза', n:'Город через 50 лет', h:'Обычное утро в вашем городе в 2076 году: что изменилось, а что осталось прежним?', p:3000, d:'8 дн. 23 ч', t:60},
    {s:'Технологии', n:'Боевой ИИ: как его переиграть', h:'Статья или рассказ о том, где у умной машины слепая зона.', p:4000, d:'13 дн.', t:80},
    {s:'Проза', n:'Первая зима на Марсе', h:'Купол, письма с Земли и первый снег из красной пыли.', p:6000, d:'3 дн. 17 ч', t:120},
    {s:'Сценарии', n:'Машина времени на один день', h:'У героя ровно сутки в прошлом. Что он успеет исправить?', p:3500, d:'10 дн. 4 ч', t:80},
    {s:'Технологии', n:'Дом, который думает сам', h:'Холодильник заказывает еду, двери узнают гостей. Где удобство, а где ловушка?', p:2500, d:'6 дн. 12 ч', t:60},
    {s:'Сценарии', n:'Последний рейс на орбиту', h:'Короткий сценарий: одна станция, один корабль, одно место на борту.', p:4500, d:'9 дн. 8 ч', t:100},
    {s:'Проза', n:'Письмо из 2100 года', h:'Ваш правнук пишет вам письмо. О чём он попросит?', p:3000, d:'11 дн. 2 ч', t:60}
  ];
  var ri = 0, rDur = 1600, rT, rot = $('rot'), rPaused = false, rLeft = rDur, rStart;
  function rFill(i){
    var c = R[i];
    $('r-sec').textContent = c.s; $('r-name').textContent = c.n; $('r-hook').textContent = c.h;
    $('r-prize').textContent = nf(c.p) + ' ₽'; $('r-left').textContent = c.d;
    $('r-th').textContent = 'Порог ' + c.t + ' баллов';
    if (c.id) rot.href = 'https://tr555.ru/contests/' + c.id;
  }
  function rGo(i){
    i = (i + R.length) % R.length;
    var sw = rot.querySelectorAll('.sw');
    if (reduce || !sw[0].animate){ ri = i; rFill(i); rArm(rDur); return; }
    sw.forEach(function(el, k){
      el.animate([{opacity:1, transform:'none', filter:'blur(0)'}, {opacity:0, transform:'translateY(-8px)', filter:'blur(2px)'}],
        {duration:260, delay:k*15, easing:'ease-in-out', fill:'forwards'});
    });
    setTimeout(function(){
      ri = i; rFill(i);
      sw.forEach(function(el, k){
        el.animate([{opacity:0, transform:'translateY(8px)', filter:'blur(2px)'}, {opacity:1, transform:'none', filter:'blur(0)'}],
          {duration:420, delay:k*20, easing:'cubic-bezier(.22,1,.36,1)', fill:'forwards'});
      });
      rArm(rDur);
    }, 260 + sw.length*15);
  }
  function rArm(ms){ clearTimeout(rT); rLeft = ms; rStart = Date.now(); if (!rPaused) rT = setTimeout(function(){ rGo(ri + 1); }, ms); }
  function rPause(on){
    if (on === rPaused) return; rPaused = on; rot.classList.toggle('paused', on);
    if (on){ clearTimeout(rT); rLeft = Math.max(300, rLeft - (Date.now() - rStart)); } else rArm(rLeft);
  }
  rot.addEventListener('mouseenter', function(){ rPause(true); });
  rot.addEventListener('mouseleave', function(){ rPause(false); });
  var rIn = !('IntersectionObserver' in window);
  document.addEventListener('visibilitychange', function(){ rPause(document.hidden || !rIn); });
  rFill(0);
  /* крутим, только когда окно на экране */
  rPaused = true; rot.classList.add('paused');
  if ('IntersectionObserver' in window) new IntersectionObserver(function(es){ rIn = es[0].isIntersecting; rPause(!rIn || document.hidden); }, {threshold:.4}).observe(rot);
  else rPause(false);

  /* реальные конкурсы: на tr555.ru подтягиваем идущие из API, иначе остаются примеры */
  function esc(s){ return String(s == null ? '' : s).replace(/[&<>"]/g, function(c){ return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]; }); }
  function prizeSum(c){
    var p = c.prizes != null ? c.prizes : c.prize;
    if (Array.isArray(p)) return p.reduce(function(a, x){ return a + Number(x && typeof x === 'object' ? (x.amount != null ? x.amount : x.value) : x) || 0; }, 0);
    return Number(p && typeof p === 'object' ? p.amount : p) || 0;
  }
  function left(iso){ var m = Math.max(0, Math.floor((new Date(iso) - Date.now())/60000)), d = Math.floor(m/1440), h = Math.floor(m%1440/60);
    return d ? d + ' дн. ' + h + ' ч' : h + ' ч ' + (m%60) + ' мин'; }
  if (/(^|\.)tr555\.ru$/.test(location.hostname) && window.fetch){
    fetch('/api/contests?state=active&page=1', {credentials:'same-origin'}).then(function(r){ return r.ok ? r.json() : null; }).then(function(d){
      if (!d || !d.items || !d.items.length) return;
      $('c-title').textContent = 'Идут сейчас';
      $('c-lead').textContent = 'Выберите тему и напишите первый текст. Чем раньше начнёте, тем больше времени на отклик читателей.';
      $('c-note').innerHTML = 'Все конкурсы и завершённые итоги на странице <a href="https://tr555.ru/contests" style="color:var(--c-accent);font-weight:600">«Конкурсы»</a>.';
      R = d.items.slice(0, 8).map(function(c){
        var t = c.topic || {};
        return {id:c.id, s:t.sectionName || 'Конкурс', n:t.name || 'Тема с призом', h:'Конкурс идёт сейчас. В зачёт идут тексты, лайки и рецензии после старта.',
          p:prizeSum(c), d:c.endsAt ? left(c.endsAt) : 'идёт', t:c.threshold || '?'};
      });
      $('r-tag').hidden = true; $('r-go').textContent = 'Участвовать →';
      ri = 0; rFill(0); rArm(rDur);
    }).catch(function(){});
  }

  /* reveal on scroll */
  var els = document.querySelectorAll('.reveal');
  if (!('IntersectionObserver' in window) || reduce){ els.forEach(function(e){ e.classList.add('in'); }); }
  else {
    var io = new IntersectionObserver(function(es){ es.forEach(function(e){ if (e.isIntersecting){ e.target.classList.add('in'); io.unobserve(e.target); } }); }, {threshold:.12});
    els.forEach(function(e){ io.observe(e); });
  }
})();
